import React from "react"
import Question from "./question"

const QuizHome = () => {
 
  return(
    <div>
      <Question />
    </div>
  )
  
};

export default QuizHome;
