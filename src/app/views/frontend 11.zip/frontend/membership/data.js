const list = [
    // {
    //   id: 1,
      
    //   price: 89,
    //   img: "https://m.media-amazon.com/images/I/810OOg88LoL._AC_UY327_FMwebp_QL65_.jpg",
    //   amount: 1,
    // },
    {
      id: 2,
      title: "108 Panchatantra Stories",
      author: "by Maple Press  | 1 September 2020",
      price: 399,
      eachprice: 150,
      img: "https://m.media-amazon.com/images/I/71rmxx8P2qL._AC_UY327_FMwebp_QL65_.jpg",
      amount: 1,
    },
  ];
  
  export default list;
  